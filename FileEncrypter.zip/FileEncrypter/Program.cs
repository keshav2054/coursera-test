﻿using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    class Program
    {
        static async Task<int> Main(string[] args)
        {
            // Usage:
            //   Encrypt (default): ConsoleApp5 <inputFolder> <outputFolder>
            //   Decrypt:           ConsoleApp5 --decrypt <inputFolder> <outputFolder>

            bool doDecrypt = false;
            string inputFolderPath, outputFolderPath;

            if (args.Length >= 1 && string.Equals(args[0], "--decrypt", StringComparison.OrdinalIgnoreCase))
            {
                doDecrypt = true;
                if (args.Length < 3)
                {
                    Console.WriteLine("Usage: ConsoleApp5 --decrypt <inputFolder> <outputFolder>");
                    return 1;
                }
                inputFolderPath = args[1];
                outputFolderPath = args[2];
            }
            else
            {
                if (args.Length < 2)
                {
                    Console.WriteLine("Usage: ConsoleApp5 <inputFolder> <outputFolder>");
                    return 1;
                }
                inputFolderPath = args[0];
                outputFolderPath = args[1];
            }

            // Your RSA public/private keys (XML) - unchanged

            string publicKey =
                @"<RSAKeyValue><Modulus>2R7+PFE/TMujl4YTtfSy7Z1YXmFWlaP1ZPMNOJK3rQYt7eiKdtVWkiXTbTyxCGLVLRcXAkImeQquDSviws3KoWyrOpZenh0Xh61kLM4/3+n3f3jyj/yJMKmNAhba54/LBO0rjgCA8/JGmB6yaOSAfehudpUdHa+zeThxtNcOKtWJSjH6qjEvxoSBh+Px8/W8T9gv8636fdM8OC4ZMiBpOgvDBDpXUq8NX8WDhTnE/+SUIQ0nwAk60/Veq5SV8kkNgbDw7OQK7E7V0oNuC/UiniourNObrXIqZblTVSVEywk3Dn2NSiwt6yNdDzuhCKvX3FdYv/xqtsyXn9J/0MY74Q==</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>";
            string privateKey =
                @"<RSAKeyValue><Modulus>2R7+PFE/TMujl4YTtfSy7Z1YXmFWlaP1ZPMNOJK3rQYt7eiKdtVWkiXTbTyxCGLVLRcXAkImeQquDSviws3KoWyrOpZenh0Xh61kLM4/3+n3f3jyj/yJMKmNAhba54/LBO0rjgCA8/JGmB6yaOSAfehudpUdHa+zeThxtNcOKtWJSjH6qjEvxoSBh+Px8/W8T9gv8636fdM8OC4ZMiBpOgvDBDpXUq8NX8WDhTnE/+SUIQ0nwAk60/Veq5SV8kkNgbDw7OQK7E7V0oNuC/UiniourNObrXIqZblTVSVEywk3Dn2NSiwt6yNdDzuhCKvX3FdYv/xqtsyXn9J/0MY74Q==</Modulus><Exponent>AQAB</Exponent><P>8AuRLf0GAqwv31KTvCKxkc42qXX598VyJbxWn4Lro21KWi/5NlIlARMiYxKidQxcxeeCgOIPZBt+gju0guTcXJJHHycIw5zTJhinARpfWWk8mrKGltvVCHss66CNYxJAKuZmcT0iVJS2rx2hJnthU4iwPG2/75WKw/JwEC/nXSs=</P><Q>541ds92Voxm7Sn/0hgZxH01vUrxiDApbljkDfmi9KmRXOaOPoSCaDynrDNGr2cA++0FxrsxGhYc366NbjAcA0RVhrThC+/ntHrO7rm9fJhnRMiQ7PDBGcx0CU9/ZiY75LT+bGUbgIx+U0L17V001/IjdwVR/qWtRyLH39miz/SM=</Q><DP>40BQJVWRRx50A9xNeKLvsLWlEjFagLMwKYFwEHsFUia5aUBZko+Z8LaIq3qMynr1qXZPGmzpXUCaN/kGH5VC+XCSXG+74FSroTldgbHR6veyJFI3EML1n53dHQVWVSCGFxcgjLvvsFtJx+cpFSFhNpAFKHBOcScFxBPU+74eLxk=</DP><DQ>b7b5pWTb5BPvE7OGQv9qpoKSmiU/XLXGmESrldpsob5Fgw6Rplh3W6eKuuWR9v3UpR5e/cmaoKOrbCmlanqaf0XEmXESiEV9jJmEjFU5X8WG850dYx2bb8BoNhVC/CYZvCX664gRbYC4KLmyf11GFa/m5XaiHRglHiIXEzBS3mc=</DQ><InverseQ>1kf4CAWbc8zfppFivmAI+gkE9o6AHiTwuuEuLifRvCdzwwJhrRoEQKjZ1vS3bIAO4TqbwMR6lzPPYF785kxyJ80AEYbl+aysN6fxwQlfoP6tUAdX0Z5acI2rqPD8miH3atcvxJ+LA0X2BtEAMDFs+LY/OhD2EVguxYGLwto52NE=</InverseQ><D>MsLWOY/dNr0dYB2Omim9c2Qn9tjW/2E3zAQvARz8KE2bi1WkmafC96Q0TAO2d/lzUXlmfbate/sNOjMabuTiDN91INtq/5hZmfTlyLvnnxf6Lyk9vIAUKvZY6zYgs6aglmREnIxtmZr4+jOjDnbtu4IN4Vd3WSts0Fhr7RWiUEzx7Dl9oXqaqw0uvk3TSZ4RroBWLUpWW9UZaYZZ5t2rzbuVkNLOzLI1Alr669Jg7hiGik58INdFkjfe4FHTp6Ks0TK6KQiEBFqyeTZKk/LmKz51eTDrMR0s/QzdGg3uWsgomz3zABVcbnIFW1w0R5UFMlnlFhGBDgIy7xizgng0CQ==</D></RSAKeyValue>";

            try
            {
                if (!Directory.Exists(inputFolderPath))
                {
                    Console.WriteLine($"Input folder not found: {inputFolderPath}");
                    return 1;
                }

                Directory.CreateDirectory(outputFolderPath);

                string[] files = Directory.GetFiles(inputFolderPath);

                int processed = 0, failed = 0;
                foreach (var filePath in files)
                {
                    // Skip directories just in case
                    if ((File.GetAttributes(filePath) & FileAttributes.Directory) == FileAttributes.Directory)
                        continue;

                    string outputFilePath = Path.Combine(outputFolderPath, Path.GetFileName(filePath));
                    try
                    {
                        if (doDecrypt)
                        {
                            await DecryptFileAsync(filePath, outputFilePath, privateKey);

                            Console.WriteLine($"Decrypted: {filePath} -> {outputFilePath}");
                        }
                        else
                        {
                            await EncryptFileAsync(filePath, outputFilePath, publicKey);
                            Console.WriteLine($"Encrypted: {filePath} -> {outputFilePath}");
                        }
                        processed++;
                    }
                    catch (CryptographicException cex)
                    {
                        Console.WriteLine($"❌ {(doDecrypt ? "Decrypt" : "Encrypt")} failed for '{filePath}': {cex.Message}");
                        failed++;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"❌ {(doDecrypt ? "Decrypt" : "Encrypt")} failed for '{filePath}': {ex.Message}");
                        failed++;
                    }
                }

                Console.WriteLine($"{(doDecrypt ? "Decryption" : "Encryption")} complete. OK={processed} Failed={failed}");
                return failed == 0 ? 0 : 2;
            }
            catch (CryptographicException ex)
            {
                Console.WriteLine($"Cryptographic error: {ex.Message}");
                return 2;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error: {ex.Message}");
                return 3;
            }
        }
        private static async Task DecryptFileAsync(string inputPath, string outputPath, string privateKey) { using var input = new FileStream(inputPath, FileMode.Open, FileAccess.Read, FileShare.Read, 1024 * 64, useAsync: true); using var plainStream = await DecryptAsync(input, privateKey); using var output = new FileStream(outputPath, FileMode.Create, FileAccess.Write, FileShare.None, 1024 * 64, useAsync: true); await plainStream.CopyToAsync(output, 1024 * 64).ConfigureAwait(false); await output.FlushAsync().ConfigureAwait(false); }

        private static async Task EncryptFileAsync(string inputFilePath, string outputFilePath, string publicKey)
        {
            using RSA rsa = RSA.Create();
            rsa.FromXmlString(publicKey);

            using Aes aes = Aes.Create();
            aes.Mode = CipherMode.CBC;
            aes.Padding = PaddingMode.PKCS7;

            byte[] iv = aes.IV;
            byte[] encryptedAesKey = rsa.Encrypt(aes.Key, RSAEncryptionPadding.OaepSHA256);

            // Ensure output file is fresh
            if (File.Exists(outputFilePath))
                File.Delete(outputFilePath);

            using FileStream input = new FileStream(inputFilePath, FileMode.Open, FileAccess.Read, FileShare.Read, 1024 * 64, useAsync: true);
            using FileStream output = new FileStream(outputFilePath, FileMode.CreateNew, FileAccess.Write, FileShare.None, 1024 * 64, useAsync: true);

            // FORMAT MUST MATCH DECRYPTOR:
            // [IV (16 bytes)] [Encrypted AES Key (NO LENGTH PREFIX)] [Ciphertext]

            await output.WriteAsync(iv, 0, iv.Length).ConfigureAwait(false);

            // 🔥 REMOVE LENGTH PREFIX — WRITE RSA KEY DIRECTLY
            await output.WriteAsync(encryptedAesKey, 0, encryptedAesKey.Length).ConfigureAwait(false);

            using ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);
            using CryptoStream cryptoStream = new CryptoStream(output, encryptor, CryptoStreamMode.Write, leaveOpen: true);

            await input.CopyToAsync(cryptoStream, 1024 * 64).ConfigureAwait(false);
            cryptoStream.FlushFinalBlock();
        }

        private static async Task<byte[]> ReadExactlyAsync(Stream s, int count)
        {
            byte[] buffer = new byte[count];
            int readTotal = 0;
            while (readTotal < count)
            {
                int r = await s.ReadAsync(buffer, readTotal, count - readTotal).ConfigureAwait(false);
                if (r == 0)
                    throw new EndOfStreamException($"Unexpected end of stream; needed {count} bytes, got {readTotal}.");
                readTotal += r;
            }
            return buffer;
        }

        private static async Task<Stream> DecryptAsync(Stream sourceFileStream, string privateKey)
        {
            Aes aes;
            byte[] ivBuffer;
            MemoryStream ms;
            byte[] keyBuffer;
            Stream stream;
            using (RSA rsa = RSA.Create())
            {
                rsa.FromXmlString(privateKey);
                aes = Aes.Create();
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;
                ivBuffer = new byte[16];
                ms = new MemoryStream();
                do
                    ;
                while (await sourceFileStream.ReadAsync(ivBuffer, 0, ivBuffer.Length) != ivBuffer.Length);
                aes.IV = ivBuffer;
                keyBuffer = new byte[256];
                do
                    ;
                while (await sourceFileStream.ReadAsync(keyBuffer, 0, keyBuffer.Length) != keyBuffer.Length);
                aes.Key = rsa.Decrypt(keyBuffer, RSAEncryptionPadding.OaepSHA256);
                using (CryptoStream cryptoStream = new CryptoStream(sourceFileStream, aes.CreateDecryptor(aes.Key, aes.IV), CryptoStreamMode.Read))
                    await cryptoStream.CopyToAsync((Stream)ms);
                try
                {
                    sourceFileStream.Close();
                    sourceFileStream.Dispose();
                }
                catch
                {
                }
                if (ms.Position != 0L)
                    ms.Position = 0L;
                stream = (Stream)ms;
            }
            aes = (Aes)null;
            ivBuffer = (byte[])null;
            ms = (MemoryStream)null;
            keyBuffer = (byte[])null;
            return stream;
        }




    }
}
