# Azure Function: App Configuration Dynamic Refresh (NET 8 isolated)

## What you get
- `POST /api/refresh` to force-refresh App Configuration (uses sentinel `App:Sentinel`).
- `GET /api/config?keys=App:Foo,App:Bar` to fetch the latest values.
- A timer that refreshes every 5 minutes.

## Setup
1. In **Azure App Configuration**, create `App:Sentinel = 1` (bump it when you change any keys).
2. In the Function App **Configuration** add:
   - `AppConfigConnectionString` = your App Configuration connection string
   - (Optional) `ASPNETCORE_ENVIRONMENT` if you use labels.
3. Deploy, then call:
   - `POST https://<app>.azurewebsites.net/api/refresh?code=<function-key>`
   - `GET  https://<app>.azurewebsites.net/api/config?keys=App:Sentinel&code=<function-key>`

## Local run
- Install .NET 8 SDK and Azure Functions Core Tools v4.
- `func start`

## Notes
- Keep authorization at `Function` level.
- Adjust `.Select()` if you use labels per environment.
