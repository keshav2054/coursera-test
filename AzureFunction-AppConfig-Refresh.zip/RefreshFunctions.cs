using System.Net;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;

public class RefreshFunctions
{
    private readonly IConfiguration _config;
    private readonly IConfigurationRefresher _refresher;
    private readonly ILogger<RefreshFunctions> _logger;

    public RefreshFunctions(IConfiguration config, IConfigurationRefresher refresher, ILogger<RefreshFunctions> logger)
    {
        _config = config;
        _refresher = refresher;
        _logger = logger;
    }

    // POST /api/refresh  -> Forces an immediate refresh
    [Function("ForceRefresh")]
    public async Task<HttpResponseData> ForceRefresh(
        [HttpTrigger(AuthorizationLevel.Function, "post", Route = "refresh")] HttpRequestData req)
    {
        try
        {
            // Ask App Configuration to refresh if the sentinel changed (or cache expired)
            await _refresher.TryRefreshAsync();

            // Touch the configuration to ensure reload happened before responding
            var sentinel = _config["App:Sentinel"];
            _logger.LogInformation("Refreshed. App:Sentinel is now: {sentinel}", sentinel);

            var res = req.CreateResponse(HttpStatusCode.OK);
            await res.WriteStringAsync($"Refreshed. App:Sentinel={sentinel ?? "(null)"}");
            return res;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to refresh App Configuration.");
            var res = req.CreateResponse(HttpStatusCode.InternalServerError);
            await res.WriteStringAsync("Failed to refresh App Configuration: " + ex.Message);
            return res;
        }
    }

    // GET /api/config?keys=App:Foo,App:Bar  -> Returns the latest values as JSON
    [Function("GetConfig")]
    public async Task<HttpResponseData> GetConfig(
        [HttpTrigger(AuthorizationLevel.Function, "get", Route = "config")] HttpRequestData req)
    {
        // Refresh first so we return latest values
        await _refresher.TryRefreshAsync();

        var query = System.Web.HttpUtility.ParseQueryString(req.Url.Query);
        var keysParam = query.Get("keys") ?? string.Empty;
        var keys = keysParam.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        var result = new Dictionary<string, string?>();
        if (keys.Length == 0)
        {
            // If no keys specified, return a small curated sample (avoid dumping everything)
            var defaults = new[] { "App:Sentinel" };
            foreach (var k in defaults) result[k] = _config[k];
        }
        else
        {
            foreach (var k in keys) result[k] = _config[k];
        }

        var res = req.CreateResponse(HttpStatusCode.OK);
        await res.WriteAsJsonAsync(result);
        return res;
    }

    // Timer refresh as a fallback (every 5 minutes)
    [Function("BackgroundRefresh")]
    public async Task RunTimer([TimerTrigger("0 */5 * * * *")] TimerInfo timer, FunctionContext ctx)
    {
        try
        {
            await _refresher.TryRefreshAsync();
            _logger.LogInformation("Background refresh completed at {time}.", DateTimeOffset.UtcNow);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Background refresh failed.");
        }
    }
}
