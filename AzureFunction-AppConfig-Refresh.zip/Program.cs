using Microsoft.Azure.Functions.Worker;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;

var host = new HostBuilder()
    .ConfigureFunctionsWorkerDefaults()
    .ConfigureAppConfiguration((context, config) =>
    {
        var built = config.Build();
        var appConfigConn = built["AppConfigConnectionString"];
        if (string.IsNullOrWhiteSpace(appConfigConn))
            throw new InvalidOperationException("AppConfigConnectionString app setting is missing.");

        config.AddAzureAppConfiguration(options =>
        {
            options.Connect(appConfigConn)
                // Load everything, adjust selectors as you like
                .Select(KeyFilter.Any, LabelFilter.Null)
                .Select(KeyFilter.Any, label: context.HostingEnvironment.EnvironmentName)

                // Configure refresh using a sentinel key you will update when anything important changes
                .ConfigureRefresh(refresh =>
                {
                    refresh.Register(key: "App:Sentinel", refreshAll: true)
                           .SetCacheExpiration(TimeSpan.FromSeconds(10));
                });
        });
    })
    .ConfigureServices((context, services) =>
    {
        // Make IConfiguration available
        services.AddSingleton(sp => sp.GetRequiredService<IConfiguration>());

        // Grab the refresher tied to the above AddAzureAppConfiguration call
        services.AddSingleton(sp =>
        {
            var cfg = sp.GetRequiredService<IConfiguration>();
            // Extension method from Microsoft.Extensions.Configuration.AzureAppConfiguration
            return cfg.GetRefresher();
        });
    })
    .Build();

await host.RunAsync();
