// ListAppConfig.cs
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;
using Azure;
using Azure.Data.AppConfiguration;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;
using Microsoft.Extensions.Logging;

namespace FIS.Function
{
    public class ListAppConfig
    {
        private readonly ILogger _log;
        private readonly IConfiguration _config;
        private readonly IConfigurationRefresher _refresher;

        public ListAppConfig(
            ILoggerFactory lf,
            IConfiguration config,
            IConfigurationRefresherProvider refresherProvider)
        {
            _log = lf.CreateLogger<ListAppConfig>();
            _config = config;

            var r = refresherProvider?.Refreshers?.FirstOrDefault();
            _refresher = r ?? throw new InvalidOperationException(
                "No IConfigurationRefresher found. Ensure AddAzureAppConfiguration() and config.AddAzureAppConfiguration(...) were called in Program.cs.");
        }

        [Function("ListConfig")]
        public async Task<HttpResponseData> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "config/list")]
            HttpRequestData req)
        {
            var res = req.CreateResponse();
            try
            {
                var q = ParseQuery(req.Url);

                // defaults
                var doRefresh = !q.TryGetValue("refresh", out var rf) || !string.Equals(rf, "false", StringComparison.OrdinalIgnoreCase);
                var resolve   = !q.TryGetValue("resolve", out var rs) || !string.Equals(rs, "false", StringComparison.OrdinalIgnoreCase);
                var labelRaw  = q.TryGetValue("label", out var lb) ? lb : "(null)"; // "(null)" | "*" | <label>

                // Build a VALID key filter (App Config supports only prefix matching: "*" or "foo*")
                var prefix = q.TryGetValue("prefix", out var px) ? px?.Trim() : "";
                string keyFilter;

                if (string.IsNullOrEmpty(prefix) || prefix == "*")
                {
                    keyFilter = "*";
                }
                else
                {
                    var starIdx = prefix.IndexOf('*');
                    if (starIdx >= 0 && starIdx != prefix.Length - 1)
                    {
                        // Return 400 to the caller for invalid pattern
                        res.StatusCode = HttpStatusCode.BadRequest;
                        await res.WriteStringAsync("Invalid 'prefix' pattern. Only prefix matching is supported. Use '*' or patterns like 'foo*'.");
                        return res;
                    }
                    keyFilter = prefix.EndsWith("*") ? prefix : $"{prefix}*";
                }

                if (doRefresh) await _refresher.TryRefreshAsync();

                // Build client from either connection string or endpoint+credential
                var endpoint = _config["AppConfigEndpoint"];
                var conn     = _config["AppConfigConnection"];
                ConfigurationClient client;

                if (!string.IsNullOrWhiteSpace(conn))
                {
                    client = new ConfigurationClient(conn);
                }
                else if (!string.IsNullOrWhiteSpace(endpoint))
                {
                    client = new ConfigurationClient(new Uri(endpoint), new Azure.Identity.DefaultAzureCredential());
                }
                else
                {
                    res.StatusCode = HttpStatusCode.BadRequest;
                    await res.WriteStringAsync("AppConfigConnection/AppConfigEndpoint not found in configuration.");
                    return res;
                }

                var selector = new SettingSelector
                {
                    KeyFilter   = keyFilter,
                    // Azure.Data.AppConfiguration semantics:
                    // null => (No label), "*" => any label, "prod" => exact label
                    LabelFilter = labelRaw == "(null)" ? null : (string.IsNullOrWhiteSpace(labelRaw) ? "*" : labelRaw)
                };

                var items = new List<object>();

                await foreach (ConfigurationSetting s in client.GetConfigurationSettingsAsync(selector))
                {
                    var isKvRef = string.Equals(
                        s.ContentType,
                        "application/vnd.microsoft.appconfig.keyvaultref+json",
                        StringComparison.OrdinalIgnoreCase);

                    var value = (resolve && isKvRef) ? _config[s.Key] : s.Value;

                    items.Add(new
                    {
                        key = s.Key,
                        label = s.Label,
                        contentType = s.ContentType,
                        lastModified = s.LastModified,
                        value
                    });
                }

                var payload = new
                {
                    ok = true,
                    count = items.Count,
                    selector = new { keyFilter = selector.KeyFilter, label = labelRaw },
                    items
                };

                res.StatusCode = HttpStatusCode.OK;
                res.Headers.Add("Content-Type", "application/json; charset=utf-8");
                await res.WriteStringAsync(JsonSerializer.Serialize(payload, new JsonSerializerOptions { WriteIndented = true }));
                return res;
            }
            catch (RequestFailedException rfe)
            {
                _log.LogError(rfe, "App Configuration request failed.");
                res.StatusCode = HttpStatusCode.InternalServerError;
                await res.WriteStringAsync($"AppConfig error: {rfe.Status} {rfe.ErrorCode} - {rfe.Message}");
                return res;
            }
            catch (Exception ex)
            {
                _log.LogError(ex, "Unhandled error in ListConfig.");
                res.StatusCode = HttpStatusCode.InternalServerError;
                await res.WriteStringAsync($"Unhandled error: {ex.Message}");
                return res;
            }
        }

        private static Dictionary<string, string> ParseQuery(Uri url)
        {
            var dict = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var q = url.Query;
            if (string.IsNullOrEmpty(q)) return dict;

            foreach (var part in q.TrimStart('?').Split('&', StringSplitOptions.RemoveEmptyEntries))
            {
                var kv = part.Split('=', 2);
                var name = Uri.UnescapeDataString(kv[0]);
                var val = kv.Length > 1 ? Uri.UnescapeDataString(kv[1]) : "";
                dict[name] = val;
            }
            return dict;
        }
    }
}
