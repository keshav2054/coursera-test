using System;
using System.Linq;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Configuration;
using Microsoft.Extensions.Logging;
using Azure.Identity;
using Microsoft.Extensions.Configuration.AzureAppConfiguration;

var host = new HostBuilder()
    .ConfigureFunctionsWorkerDefaults()
    .ConfigureAppConfiguration((context, config) =>
    {
        // Build initial configuration to read the App Config connection string from local.settings.json / App Settings
        var preConfig = config.Build();
        var appConfigConnection = preConfig["AppConfigConnection"];
        var appConfigEndpoint = preConfig["AppConfigEndpoint"];

        config.AddAzureAppConfiguration(options =>
        {
            if (!string.IsNullOrEmpty(appConfigConnection))
            {
                options.Connect(appConfigConnection);
            }
            else if (!string.IsNullOrEmpty(appConfigEndpoint))
            {
                options.Connect(new Uri(appConfigEndpoint), new DefaultAzureCredential());
            }
            else
            {
                throw new InvalidOperationException("Provide either 'AppConfigConnection' or 'AppConfigEndpoint' in configuration.");
            }

            options.ConfigureKeyVault(kv => kv.SetCredential(new DefaultAzureCredential()));

            // Select the keys you want available in this Function App
            options.Select(KeyFilter.Any, LabelFilter.Null);
            options.Select(KeyFilter.Any, "prod");

            // Setup dynamic refresh using a sentinel key
            options.ConfigureRefresh(refresh =>
            {
                refresh.Register(key: "appsettings:sentinel", label: LabelFilter.Null, refreshAll: true);
                refresh.SetRefreshInterval(TimeSpan.FromSeconds(1)); // renamed from SetCacheExpiration
            });

        });
    })
    // Required so we can resolve IConfigurationRefresherProvider in the Function
    .ConfigureServices(services =>
    {
        services.AddAzureAppConfiguration();
    })
    .Build();

await host.RunAsync();
